﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace RemoteTaskList
{
    public partial class Service2 : ServiceBase
    {
        public Service2()
        {
            InitializeComponent();
        }

        protected async override void OnStart(string[] args)
        {
            await ServiceHandler.Start();
        }

        protected override void OnStop()
        {
            ServiceHandler.Stop();
            
        }
    }
}
