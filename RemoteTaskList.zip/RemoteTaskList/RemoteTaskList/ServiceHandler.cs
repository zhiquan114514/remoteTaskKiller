﻿using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RemoteTaskList
{
    class ServiceHandler
    {

        static readonly string logPath = @"F:\RemoteTaskListService\log.txt";


        static string connectionString = "Endpoint=sb://testcom.servicebus.windows.net/;SharedAccessKeyName=root;SharedAccessKey=uDBa+lZtz8YN5jVQm5XnhFexIU8SYYWo1Z4xQT58xD8=;EntityPath=sendqueue";
        static string queueName = "sendqueue";
        /*static string connectionString1 = "Endpoint=sb://testcom.servicebus.windows.net/;SharedAccessKeyName=root;SharedAccessKey=dyUA9xPXO1vovOwmiG1svaBWImw9efYD/0u3/vHXg2g=;EntityPath=receivequeue";
        static string queueName1 = "receivequeue";
        static ServiceBusClient sendBackClient;
        static ServiceBusClient*/
          static ServiceBusClient client;
        static ServiceBusProcessor processor;
        static readonly FileStream stream = new FileStream(logPath, FileMode.Append);
        static readonly StreamWriter writer = new StreamWriter(stream);
       /* private static readonly string EndpointUri = "https://zhiquan.documents.azure.com:443/";
        private static readonly string PrimaryKey = "shRVnjAaYFMdmZvfiHC2cr41U3KvTx4Gx0E5NXjnYGMpdSF3t6LR4m8e7jRh4ezY3l131QeaUQJgZR9TysF1zA==";
        private CosmosClient cosmosClient;
        private Database database;
        private Container container;
        private string databaseId = "ToDoList";
        private string containerId = "Items";
       */
        private static Process[] process;
        private static ProcessInfo[] processInfos;
        private static string json;
        private static SendPackage sendPackage;
        public class ProcessInfo
        {
            public string processName;
            public int pid;
        }
        public class SendPackage
        {
            public string id { get; set; }
            public string request { get; set; }
            public string response { get; set; }
            public string dateTime { get; set; }
        }
        public class Order
        {
            public string id { get; set; }
            public string command { get; set; }

        }
        public async static Task Start()
        {
            client = new ServiceBusClient(connectionString);
            processor = client.CreateProcessor(queueName, new ServiceBusProcessorOptions());


            processor.ProcessMessageAsync += MessageHandler;
            processor.ProcessErrorAsync += ErrorHandler;
            writer.WriteLine($"在{DateTime.Now} 开始监听远程端的消息");
            writer.Flush();

            await processor.StartProcessingAsync();

        }
        public static Order order;
        static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            writer.WriteLine($"在{DateTime.Now} 发生了错误，错误详情: {args.Exception.ToString()}");
            writer.Flush();
            Console.WriteLine();
            return Task.CompletedTask;
        }

        static async Task MessageHandler(ProcessMessageEventArgs args)
        {

            string message = args.Message.Body.ToString();
            writer.WriteLine($"在{DateTime.Now} 收到指令: {message}");
            writer.Flush();
             order = JsonConvert.DeserializeObject<Order>(message);
            
            if (order.command.Equals("tasklist"))
            {
            process = Process.GetProcesses();
            processInfos = new ProcessInfo[process.Length];
            for (int i = 0; i < process.Length; ++i)
            {
                processInfos[i] = new ProcessInfo();
                processInfos[i].processName = process[i].ProcessName;
                processInfos[i].pid = process[i].Id;
            }
            json = JsonConvert.SerializeObject(processInfos, Formatting.Indented);
            /*writer.WriteLine(json);
            writer.Flush();
            */
            sendPackage = new SendPackage();
            sendPackage.response = json;

           /* try
            {
                ServiceHandler p = new ServiceHandler();
                await p.GetStartedDemoAsync();
            }
            catch (CosmosException de)
            {
                Exception baseException = de.GetBaseException();
                Console.WriteLine("{0} error occurred: {1}", de.StatusCode, de);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e);
            }*/

            }

        }
        public async static void Stop()
        {
            try
            {
                // 停止接收 
                writer.WriteLine($"在{DateTime.Now} 服务被关闭了");
                writer.Flush();
                writer.Close();
                await processor.StopProcessingAsync();

            }
            finally
            {
                await processor.DisposeAsync();
                await client.DisposeAsync();
            }
        }

        private async Task GetStartedDemoAsync()
        {
            this.cosmosClient = new CosmosClient(EndpointUri, PrimaryKey, new CosmosClientOptions() { ApplicationName = "JSONTest" });
            await this.CreateDatabaseAsync();
            await this.CreateContainerAsync();
            //await this.ScaleContainerAsync();
            await this.AddItemsToContainerAsync();
            //await this.QueryItemsAsync();
            // await this.ReplaceProcessItemAsync();
            // await this.DeleteProcessItemAsync();
            // await this.DeleteDatabaseAndCleanupAsync();
        }
        private async Task CreateContainerAsync()
        {
            this.container = await this.database.CreateContainerIfNotExistsAsync(containerId, "/id");
            Console.WriteLine("Created Container: {0}\n", this.container.Id);
        }
                private async Task CreateDatabaseAsync()
        {
            // Create a new database
            this.database = await this.cosmosClient.CreateDatabaseIfNotExistsAsync(databaseId);
            Console.WriteLine("Created Database: {0}\n", this.database.Id);
        }
        private async Task AddItemsToContainerAsync()
        {
            try
            {

                ItemResponse<SendPackage> processJsonResponse = await this.container.ReadItemAsync<SendPackage>(order.id, new PartitionKey(sendPackage.id));
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                //理论上来说，没有的话就会被catch到Exception，转到这里来用一模一样的信息创建一个
                sendPackage.id = order.id;
                sendPackage.request = "tasklist request";
                sendPackage.dateTime = DateTime.Now.ToString();
                ItemResponse<SendPackage> processJsonResponse = await this.container.CreateItemAsync<SendPackage>(sendPackage, new PartitionKey(sendPackage.id));
               
            }
        }

    }
}
