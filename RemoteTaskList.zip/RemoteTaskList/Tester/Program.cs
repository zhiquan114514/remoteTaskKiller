﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            string json ="";
            Process[] localAll = Process.GetProcesses();
            ProcessInfo[] info = new ProcessInfo[localAll.Length];

            for (int i = 0; i < localAll.Length; ++i)
            {
                info[i] = new ProcessInfo();
                info[i].processName = localAll[i].ProcessName;
                info[i].pid = localAll[i].Id;
            }


                json = JsonConvert.SerializeObject(info,Formatting.Indented);

            Console.WriteLine(json);
            Console.ReadKey();

        }
    }
}
