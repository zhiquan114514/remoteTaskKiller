﻿using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WebTest.Controllers.TaskListController
{
    public class TaskListController : Controller
    {
        static readonly string logPath = @"F:\weblog.txt";
        static readonly FileStream stream = new FileStream(logPath, FileMode.Append);
        static readonly StreamWriter writer = new StreamWriter(stream);
        static string connectionString = "Endpoint=sb://testcom.servicebus.windows.net/;SharedAccessKeyName=root;SharedAccessKey=uDBa+lZtz8YN5jVQm5XnhFexIU8SYYWo1Z4xQT58xD8=;EntityPath=sendqueue";
        static string queueName = "sendqueue";
        static ServiceBusClient client;
        static ServiceBusSender sender; 
        public class Order
        {
            public string id { get; set; }
            public string command { get; set; }
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Send()
        {
            Guid guid = Guid.NewGuid();
            Task task = ListOperation(guid);
            task.Wait();
            return Content(guid.ToString());
        }
        static async Task ListOperation(Guid guid)
        {
            //service bus 是单例模式

            client = new ServiceBusClient(connectionString);
            sender = client.CreateSender(queueName);

            using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();
            Order order = new Order();
            order.id = guid.ToString();
            order.command = "tasklist";
            string json = JsonConvert.SerializeObject(order);
            if (!messageBatch.TryAddMessage(new ServiceBusMessage(json)))
            {
                throw new Exception($"命令 {json } 不能被发送");
            }
            try
            {
                await sender.SendMessagesAsync(messageBatch);
                Console.WriteLine("消息已经成功被发送");
            }
            finally
            {

                await sender.DisposeAsync();
                await client.DisposeAsync();
            }
        }
        public class ReceivePackage
        {
            public string id { get; set; }
            public string request { get; set; }
            public string response { get; set; }
            public string dateTime { get; set; }
        }

        private static readonly string EndpointUri = "https://zhiquan.documents.azure.com:443/";
        private static readonly string PrimaryKey = "shRVnjAaYFMdmZvfiHC2cr41U3KvTx4Gx0E5NXjnYGMpdSF3t6LR4m8e7jRh4ezY3l131QeaUQJgZR9TysF1zA==";
        private Container container;
        private Database database;
        private CosmosClient cosmosClient;
        private string databaseId = "ToDoList";
        private string containerId = "Items";
        ReceivePackage NewPackage = new ReceivePackage();

        public  IActionResult query(string id)
        {
            this.cosmosClient = new CosmosClient(EndpointUri, PrimaryKey, new CosmosClientOptions() { ApplicationName = "CosmosDBDotnetQuickstart" });
            Task task = queryOperation(id);
            task.Wait();
            string json = NewPackage.response;
            /*writer.WriteLine($"{}");
            writer.Flush();*/
            return Content(json);
        }
        public async Task queryOperation(string id) {
            writer.WriteLine($"received id: {id}");
            writer.Flush();
            var sqlQueryText = $"SELECT * FROM c WHERE c.id = '{id}'";
            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
            this.database = await this.cosmosClient.CreateDatabaseIfNotExistsAsync(databaseId);
            this.container = await this.database.CreateContainerIfNotExistsAsync(containerId, "/id");
            FeedIterator<ReceivePackage> queryResultSetIterator = this.container.GetItemQueryIterator<ReceivePackage>(queryDefinition);

            while (queryResultSetIterator.HasMoreResults)
            {
                FeedResponse<ReceivePackage> currentResultSet = await queryResultSetIterator.ReadNextAsync();
                foreach (ReceivePackage package in currentResultSet)
                {
                    NewPackage = package;
                }
            }

        }

        [HttpPost]
        public ActionResult getPost(string json)
        {
            writer.WriteLine(json);
            writer.Flush();
            return Content(json);
        }
    }


}
