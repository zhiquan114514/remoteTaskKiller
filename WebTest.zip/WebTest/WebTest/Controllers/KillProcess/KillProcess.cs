﻿using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace WebTest.Controllers.KillProcess
{
    public class KillProcess : Controller
    {
        static string connectionString = "Endpoint=sb://testcom.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=Y+4U9VOz2m0TnNdYMEi+NlusJi4wGk0fSg3TZFi4T3U=";
        static string queueName = "myqueue";
        static ServiceBusClient client;


        // the sender used to publish messages to the queue
        static ServiceBusSender sender;
        public IActionResult Index(int pid)
        {
            Task task = KillOperation(pid);
            task.Wait();

            return View();
        }
        static async Task KillOperation(int pid)
        {

            //service bus 是单例模式

            // Create the clients that we'll use for sending and processing messages.
            client = new ServiceBusClient(connectionString);
            sender = client.CreateSender(queueName);

            // create a batch 
            using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();

            var message = pid;

            if (!messageBatch.TryAddMessage(new ServiceBusMessage(message.ToString())))
            {
                throw new Exception($"命令 {message } 不能被发送");
            }
            try
            {
                // Use the producer client to send the batch of messages to the Service Bus queue
                await sender.SendMessagesAsync(messageBatch);
                Console.WriteLine("消息已经成功被发送");
            }
            finally
            {
                // Calling DisposeAsync on client types is required to ensure that network
                // resources and other unmanaged objects are properly cleaned up.
                await sender.DisposeAsync();
                await client.DisposeAsync();
            }

            Console.WriteLine("Press any key to end the application");

        }
    }
}
